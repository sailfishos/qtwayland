/****************************************************************************
**
** Copyright (C) 2012 Digia Plc and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/legal
**
** This file is part of the plugins of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and Digia.  For licensing terms and
** conditions see http://qt.digia.com/licensing.  For further information
** use the contact form at http://qt.digia.com/contact-us.
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 2.1 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU Lesser General Public License version 2.1 requirements
** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Digia gives you certain additional
** rights.  These rights are described in the Digia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3.0 as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL included in the
** packaging of this file.  Please review the following information to
** ensure the GNU General Public License version 3.0 requirements will be
** met: http://www.gnu.org/copyleft/gpl.html.
**
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef QWAYLANDSHMBACKINGSTORE_H
#define QWAYLANDSHMBACKINGSTORE_H

#include "qwaylandbuffer.h"

#include "qwaylanddecoration.h"
#include "qwaylandshmwindow.h"

#include <qpa/qplatformbackingstore.h>
#include <QtGui/QImage>
#include <qpa/qplatformwindow.h>

QT_BEGIN_NAMESPACE

class QWaylandDisplay;

class QWaylandShmBuffer : public QWaylandBuffer {
public:
    QWaylandShmBuffer(QWaylandDisplay *display,
           const QSize &size, QImage::Format format);
    ~QWaylandShmBuffer();
    QSize size() const { return mImage.size(); }
    QImage *image() { return &mImage; }

    QImage *imageInsideMargins(const QMargins &margins);
private:
    QImage mImage;
    struct wl_shm_pool *mShmPool;
    QMargins mMargins;
    QImage *mMarginsImage;
};

class QWaylandShmBackingStore : public QPlatformBackingStore
{
public:
    QWaylandShmBackingStore(QWindow *window);
    ~QWaylandShmBackingStore();

    QPaintDevice *paintDevice();
    void flush(QWindow *window, const QRegion &region, const QPoint &offset);
    void resize(const QSize &size, const QRegion &staticContents);
    void resize(const QSize &size);
    void beginPaint(const QRegion &);
    void endPaint();

    QWaylandDecoration *windowDecoration() const;

    QMargins windowDecorationMargins() const;
    QImage *entireSurface() const;
    void ensureSize();

    QWaylandShmWindow *waylandWindow() const;
    void iterateBuffer();

private:
    void updateDecorations();

    QWaylandDisplay *mDisplay;
    QWaylandShmBuffer *mFrontBuffer;
    QWaylandShmBuffer *mBackBuffer;
    bool mFrontBufferIsDirty;
    bool mPainting;

    QSize mRequestedSize;
    Qt::WindowFlags mCurrentWindowFlags;

    static const struct wl_callback_listener frameCallbackListener;
    static void done(void *data,
             struct wl_callback *callback,
             uint32_t time);
    struct wl_callback *mFrameCallback;
};

inline QWaylandDecoration *QWaylandShmBackingStore::windowDecoration() const
{
    return waylandWindow()->decoration();
}

inline QMargins QWaylandShmBackingStore::windowDecorationMargins() const
{
    if (windowDecoration())
        return windowDecoration()->margins();
    return QMargins();
}

inline QWaylandShmWindow *QWaylandShmBackingStore::waylandWindow() const
{
    return static_cast<QWaylandShmWindow *>(window()->handle());
}

QT_END_NAMESPACE

#endif
